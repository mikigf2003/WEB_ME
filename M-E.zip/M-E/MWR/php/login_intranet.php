<?php

session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}
// Manejar el cierre de sesión
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("login_intranet.php");
    exit();
}
?>
<head>
<script>
        function mostrarPopup(mensaje) {
            alert(mensaje);
        }
    </script>
</head>
<?php
// Manejar el inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $usuario = $_POST["usuario"];
    $contrasenya = $_POST["contrasenya"];
    $contrasenya = md5($contrasenya);

    // Realizar una consulta para verificar las credenciales
    $query = "SELECT * FROM clientes WHERE usuario = '$usuario' AND contrasenya = '$contrasenya'";
    $result = mysqli_query($connexio, $query);

    if (mysqli_num_rows($result) > 0) {
        $usuario = mysqli_fetch_assoc($result);
        $_SESSION["usuario"] = $usuario["usuario"];
        $_SESSION["role"] = $usuario["role"];

        // Redirigir según el rol
        if ($usuario["role"] == "Cliente") {
            $_SESSION['authenticated'] = true;
            jsRedirect("cliente.php");
            exit();
        }
    }
}

// Manejar el registro de usuarios
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    // Recibir datos del formulario
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $usuario = $_POST["usuario"];
    $contrasenya = $_POST["contrasenya"];
    $contrasenya = md5($contrasenya);

    // Verificar si el nombre de usuario ya existe en la base de datos
    $query_check_user = "SELECT * FROM clientes WHERE usuario = '$usuario'";
    $result_check_user = mysqli_query($connexio, $query_check_user);

    if (mysqli_num_rows($result_check_user) > 0) {
        // El nombre de usuario ya está en uso, mostrar mensaje de error
        echo "<script>mostrarPopup('El nombre de usuario ya está en uso');</script>";
    } else {
        // Insertar los datos en la base de datos
        $query_insert = "INSERT INTO clientes (nombre, dni, telefono, correo, usuario, contrasenya, empresa, role) 
                         VALUES ('$nombre', NULL, '$telefono', '$correo', '$usuario', '$contrasenya', NULL, 'Cliente')";

        $result_insert = mysqli_query($connexio, $query_insert);

        if ($result_insert) {
            // Registro exitoso, puedes redirigir a una página de éxito o mostrar un mensaje
            echo "<script>mostrarPopup('Registro exitoso');</script>";
        } else {
            // Error en el registro, puedes mostrar un mensaje de error o registrar el error en un archivo de registro
            echo "<script>mostrarPopup('Error al registrarte');</script>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intranet - MWR Transportes</title>

    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }

        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #f8f8f8;
        }

        .container-form {
            display: flex;
            border-radius: 20px;
            box-shadow: 0 5px 7px rgba(0, 0, 0, .1);
            height: 400px;
            max-width: 700px;
            transition: all 1s ease;
            margin: 10px;
        }

        .information {
            width: 40%;
            display: flex;
            align-items: center;
            text-align: center;
            background-color: #c7eef3;
            border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
        }

        .info-childs {
            width: 100%;
            padding: 0 30px;
        }

        .info-childs h2 {
            font-size: 2.5rem;
            color: #333;
        }

        .info-childs p {
            margin: 15px 0;
            color: #555;
        }

        .info-childs input {
            background-color: transparent;
            outline: none;
            border: solid 2px #9191bd;
            border-radius: 20px;
            padding: 10px 20px;
            color: #9191bd;
            cursor: pointer;
            transition: background-color .3s ease;
        }

        .info-childs input:hover {
            background-color: #9191bd;
            border: none;
            color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
        }

        .form-information {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60%;
            text-align: center;
            background-color: #f8f8f8;
            border-top-right-radius: 20px;
            border-bottom-right-radius: 20px;
        }

        .form-information-childs {
            padding: 0 30px;
        }

        .form-information-childs h2 {
            color: #333;
            font-size: 2rem;
        }

        .form-information-childs p {
            color: #555;
        }

        .icons {
            margin: 15px 0;
        }

        .icons i {
            border-radius: 50%;
            padding: 15px;
            cursor: pointer;
            margin: 0 10px;
            color: #9191bd;
            border: solid thin #9191bd;
            transition: background-color 0.3s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
        }

        .icons i:hover {
            background-color: #c7c7f3;
            color: #fff;
        }

        .form {
            margin: 30px 0 0 0;
        }

        .form label {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            border-radius: 20px;
            padding: 0 10px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
        }

        .form label input {
            width: 100%;
            padding: 10px;
            background-color: #fff;
            border: none;
            outline: none;
            border-radius: 20px;
            color: #333;
        }

        .form label i {
            color: #a7a7a7;
        }

        .form input[type="submit"] {
            background-color: #9191bd;
            color: #fff;
            border-radius: 20px;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            margin-top: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
        }

        .form input[type="submit"]:hover {
            background-color: #7a7a9a;
        }

        .hide {
            position: absolute;
            transform: translateY(-300%);
        }

        /*PERSONALIZACION DE MIS ALERTAS Y MENSAJES */
        .form div .alerta {
            width: 290px;
            text-align: left;
            border-radius: 7px;
            margin-bottom: 10px;
            font-size: .8rem;
        }

        .form>.alerta-error,
        .form>.alerta-exito {
            display: none;
        }

        .form .alertaError {
            display: block;
            background-color: #F66060;
            padding: .5rem 1rem;
            margin-top: 10px;
            font-weight: 500;
            font-size: .8rem;
        }

        .form .alertaExito {
            display: block;
            background-color: #0ca828;
            padding: .5rem 1rem;
            margin-top: 10px;
            font-weight: 500;
            font-size: .8rem
        }
    </style>
</head>

<body>

    <div class="container-form login hide">
        <div class="information">
            <div class="info-childs">
                <h2>¡¡Accede!!</h2>
                <p>Inicia sesión con tus credenciales para poder ver todos tus datos y pedidos</p>
                <input type="button" value="Registrarse" id="sign-up">
            </div>
        </div>
        <div class="form-information">
            <div class="form-information-childs">
                <h2>Iniciar Sesión</h2>
                <form action="login_intranet.php" class="form form-register" method="post">
                    <div>
                        <label>
                            <input type="text" id="usuario" name="usuario" placeholder="Usuario">
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="password" id="contrasenya" name="contrasenya" placeholder="Contraseña">
                        </label>
                    </div>
                    <input type="hidden" name="login">
                    <input type="submit" value="Iniciar Sesión">
                </form>
            </div>
        </div>
    </div>

    <div class="container-form register">
        <div class="information">
            <div class="info-childs">
                <h2>Bienvenido</h2>
                <p>Únete a nosotros para poder gestionar todos tus pedidos y localizarlos</p>
                <input type="button" value="Iniciar Sesión" id="sign-in">
            </div>
        </div>
        <div class="form-information">
            <div class="form-information-childs">
                <h2>Crear una Cuenta</h2>
                <form method="post" class="form form-register" action="login_intranet.php">
                    <div>
                        <label>
                            <input type="text" id="nombre" name="nombre" placeholder="Nombre" required>
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="email" id="correo" name="correo" placeholder="Correo" required>
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="text" id="telefono" name="telefono" placeholder="Teléfono" required>
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="text" id="usuario" name="usuario" placeholder="Usuario" required>
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="password" id="contrasenya" name="contrasenya" placeholder="Contraseña" required>
                        </label>
                    </div>
                    <input type="hidden" name="register">
                    <input type="submit" value="Registro">
                </form>
            </div>
        </div>
    </div>
    <script src="../js/script.js"></script>

</body>

</html>
