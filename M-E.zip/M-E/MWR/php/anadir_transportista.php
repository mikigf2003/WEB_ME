<?php
session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}

// Verifica si el usuario está autenticado; si no lo está, redirige a la página de inicio de sesión
if (!$_SESSION['authenticated']) {
    jsRedirect("Location: login_intranet.php");
}

// Destruye la sesión y redirige a la página de inicio de sesión si se envía el formulario oculto
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("Location: login_intranet.php");
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Transportista</title>

    <style>
        body {
            background: radial-gradient(circle, #ff3333, #cc0000);
            color: white;
            padding-top: 50px;
        }

        form {
            border: 2px solid black;
            background-color: white;
            margin-top: 50px;
            margin-left: 300px;
            width: 50%;
            display: flex;
            flex-wrap: wrap;
            text-align: center;
            color: black;
        }

        input,
        select {
            display: inline-block;
            border: 1px solid black;
            margin-top: 20px;
            margin-left: 5px;
            margin-bottom: 20px;
            width: 200px;
        }

        label {
            display: inline-block;
            margin-top: 20px;
            margin-left: 10px;
            margin-bottom: 20px;
            width: 90px;
        }

        .button {
            margin-left: 220px;
        }

        a {
            text-decoration: none;
            color: black;
            border: 1px solid black;
            background-color: white;
            border-radius: 5px;
            padding: 3px;
        }
    </style>
    <script>
        function mostrarPopup(mensaje) {
            alert(mensaje);
        }
    </script>
</head>

<body>

    <?
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Validar y sanitizar datos
        $nombre = mysqli_real_escape_string($connexio, $_POST['nombre']);
        $edad = mysqli_real_escape_string($connexio, $_POST['edad']);
        $dni = mysqli_real_escape_string($connexio, $_POST['dni']);
        $experiencia = mysqli_real_escape_string($connexio, $_POST['experiencia']);
        $telefono = mysqli_real_escape_string($connexio, $_POST['telefono']);
        $servicio = mysqli_real_escape_string($connexio, $_POST['servicio']);

        // Insertar los datos en la base de datos
        $sql_insertar = "INSERT INTO transportista (nombre, edad, dni, experiencia, telefono, servicio) VALUES ('$nombre', '$edad', '$dni', '$experiencia', '$telefono', '$servicio')";

        $result = mysqli_query($connexio, $sql_insertar);

        if ($result) {
            echo "<script>mostrarPopup('Añadido correctamente');</script>";
        } else {
            echo "<script>mostrarPopup('Error al añadirlo);</script>";
        }
    }
    ?>
    <h2>Añadir Nuevo Transportista</h2>
    <a href="./transportistas.php">Volver a página anterior</a>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" placeholder="Nombre" required><br>

        <label for="edad">Edad:</label><br>
        <input type="number" id="edad" name="edad" placeholder="Edad" required><br>

        <label for="dni">DNI:</label><br>
        <input type="text" id="dni" name="dni" placeholder="DNI" required><br>

        <label for="experiencia">Experiencia:</label><br>
        <input type="text" id="experiencia" name="experiencia" placeholder="Experiencia" required><br>

        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" placeholder="Teléfono" required><br>

        <label for="servicio">Servicio:</label><br>
        <select id="servicio" name="servicio" required>
            <option value="">Seleccionar</option>
            <option value="aereo">Aéreo</option>
            <option value="maritimo">Marítimo</option>
            <option value="carretera">Carretera</option>
        </select><br>

        <input type="submit" value="Añadir Transportista" class="button">
    </form>
</body>

</html>
