<?php
session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}

// Verifica si el usuario está autenticado; si no lo está, redirige a la página de inicio de sesión
if (!$_SESSION['authenticated']) {
    jsRedirect("login_intranet.php");
}

// Destruye la sesión y redirige a la página de inicio de sesión si se envía el formulario oculto
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("login_intranet.php");
}
// Función para cerrar sesión
function cerrarSesion()
{
    // Destruye todas las variables de sesión
    session_unset();

    // Destruye la sesión
    session_destroy();

    // Redirige al usuario a la página de inicio de sesión
    jsRedirect("../html/home.html");
    exit;
}

// Verifica si se ha enviado el parámetro para salir
if (isset($_GET['salir'])) {
    // Cierra la sesión
    cerrarSesion();
}
?>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MWR - Gestor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {

            text-align: left;
            padding: 5px;
        }

        h3 {

            background-color: white;
            text-align: center;
        }

        #menu {
            background-color: #e04747;
            width: 200px;
            height: 100%;
            position: fixed;
            left: 0;
            top: 0;
            padding-top: 20px;
            overflow-y: auto;
            text-align: left;
            margin-left: 0px;
        }

        #menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        #menu ul li {
            padding: 10px 20px;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 7px;
        }

        #menu ul li:hover {
            background-color: red;
        }

        #menu ul li ul {
            display: none;
            list-style: none;
            padding: 0;
            margin: 0;
            padding-left: 20px;
        }

        #menu ul li:hover ul {
            display: block;
        }

        #menu ul li ul li {
            padding: 8px 0;

        }

        a {
            text-decoration: none;
            color: white;
        }

        .logout {

            vertical-align: bottom;
        }

        .cabecera {

            background-image: url(../Images/fondo_php.png);
            background-repeat: no-repeat;
            background-size: cover;
            align-items: center;
            width: 85%;
            height: 200px;
            margin-bottom: 40px;
        }

        .cabecera h1 {

            padding-top: 150px;
            color: white;
            text-shadow: #333;
        }

        div {

            text-align: center;
            margin-left: 200px;
        }

        .datos-clientes a {

            background-color: #e04747;
            border: 1px solid black;
            margin-bottom: 10px;
            padding: 5px;
        }

        section {

            border: 1px solid #e04747;
            border-top: 28px solid #e04747;
            display: inline-block;
            margin: 10px;
            width: 25%;
            height: 150px;
        }

        .datos-clientes {
            margin: 20px auto;
            margin-left: 250px;
            max-width: 1000px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.8);
        }

        .datos-clientes h3 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
            text-align: left;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        table th,
        table td {
            border: 1px solid #ccc;
            padding: 5px;
        }

        table th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f5f5f5;
        }

        .buttonsalir {

            margin-left: 60px;
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 2px;
            padding-bottom: 2px;
            border-radius: 10px;
            background-color: white;
            color: black;
            vertical-align: bottom;
        }
    </style>
    <script>
        function mostrarPopup(mensaje) {
            alert(mensaje);
        }
    </script>

</head>

<body>
    <div id="menu">
        <h3><?php echo $_SESSION["usuario"]; ?></h3>
        <ul>
            <?php if ($_SESSION['role'] == 'Administrador') : ?>
                <li><a href="administrador.php">Inicio</a></li>
            <?php elseif ($_SESSION['role'] == 'Trabajador') : ?>
                <li><a href="trabajador.php">Inicio</a></li>
            <?php endif; ?>
            <li>Usuarios
                <ul>
                    <li><a href="ucliente.php">Clientes</a></li>
                    <?php if ($_SESSION['role'] == 'Administrador') : ?>
                        <li><a href="utrabajador.php">Trabajadores</a></li>
                    <?php elseif ($_SESSION['role'] == 'Trabajador') : ?>
                        <li><a href=""></a>Trabajadores</li>
                    <?php endif; ?>
                </ul>
            </li>
            <li><a href="pedidos.php">Pedidos</a></li>
            <li><a href="transportistas.php">Transportistas</a></li>
            <li>Atención Clientes</li>
            <li>Otros</li>
        </ul>

        <!-- Enlace para cerrar sesión -->
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?salir=1" class="buttonsalir">Salir</a>
    </div>

    <div class="cabecera">
        <h1>Datos de los trabajadores</h1>
    </div>


    <div class="datos-clientes">
        <h3>Datos de los trabajadores de MWR</h3>
        <?php
        // Procesar la actualización si se envió un formulario de edición
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_trabajador'])) {
            $id_trabajador_editar = $_POST['id_trabajador'];
            $nombre_editar = $_POST['nombre'];
            $apellido_editar = $_POST['apellido'];
            $correo_editar = $_POST['correo'];
            $telefono_editar = $_POST['telefono'];
            $usuario_editar = $_POST['usuario'];
            $role_editar = $_POST['role'];

            $sql_actualizar = "UPDATE trabajadores SET
        nombre = '$nombre_editar', 
        apellido = '$apellido_editar', 
        correo = '$correo_editar',
        telefono = '$telefono_editar',
        usuario = '$usuario_editar',
        role = '$role_editar'
        WHERE id_trabajador = $id_trabajador_editar";

            $result = mysqli_query($connexio, $sql_actualizar);

            if ($result) {
                echo "<script>mostrarPopup('Datos editados correctamente');</script>";
            } else {
                echo "<script>mostrarPopup('Error al editar datos');</script>";
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar_trabajador'])) {
            $id_trabajador_borrar = $_POST['id_trabajador'];

            $sql_borrar = "DELETE FROM trabajadores WHERE id_trabajador = $id_trabajador_borrar";

            $resultado = mysqli_query($connexio, $sql_borrar);

            if ($resultado) {
                echo "<script>mostrarPopup('Dado de baja correctamente');</script>";
            } else {
                echo "<script>mostrarPopup('Error al dar la baja');</script>";
            }
        }

        // Mostrar la información de los trabajadores
        $sql = "SELECT * FROM trabajadores";
        $mostrar = mysqli_query($connexio, $sql);
        ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Telefono</th>
                <th>Usuario</th>
                <th>Rol</th>
                <th>Editar</th>
                <th>Dar de baja</th>
            </tr>

            <?php

            while ($info = mysqli_fetch_assoc($mostrar)) {
                echo "<tr>";
                echo "<td>" . $info['id_trabajador'] . "</td>";
                echo "<form method='post' action='" . $_SERVER['PHP_SELF'] . "'>";

                echo "<input type='hidden' name='id_trabajador' value='" . $info['id_trabajador'] . "'>";
                echo "<td><input type='text' name='nombre' style='width:100px;' value='" . $info['nombre'] . "'></td>";
                echo "<td><input type='text' name='apellido' style='width:100px;' value='" . $info['apellido'] . "'></td>";
                echo "<td><input type='mail' name='correo' value='" . $info['correo'] . "'></td>";
                echo "<td><input type='text' name='telefono' style='width:100px;' value='" . $info['telefono'] . "'></td>";
                echo "<td><input type='text' name='usuario' style='width:100px;' value='" . $info['usuario'] . "'></td>";
                echo "<td><input type='text' name='role' style='width:100px;' value='" . $info['role'] . "'></td>";
                echo "<td><button type='submit' style='width:100px;'name='editar_trabajador'>Editar</button></td>";
                echo "<td><button type='submit' style='width:100px;' name='eliminar_trabajador'>Dar de baja</button></td>";
                echo "</form>";
                echo "</tr>";
            }
            ?>
        </table>
        <a href="anadir_trabajador.php">Registrar nuevo trabajador</a>
    </div>

</body>

</html>
