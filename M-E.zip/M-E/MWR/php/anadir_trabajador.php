<?php
session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}

// Verifica si el usuario está autenticado; si no lo está, redirige a la página de inicio de sesión
if (!$_SESSION['authenticated']) {
    jsRedirect("login_intranet.php");
}

// Destruye la sesión y redirige a la página de inicio de sesión si se envía el formulario oculto
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("login_intranet.php");
}

function generar_contrasenya($longitud = 12)
{
    $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+';
    $contrasenya_c = '';
    $caracteres_length = strlen($caracteres);
    for ($i = 0; $i < $longitud; $i++) {
        $contrasenya_c .= $caracteres[rand(0, $caracteres_length - 1)];
    }
    // Aplicar el hash MD5 a la contraseña generada
    $contrasenya = md5($contrasenya_c);
    return $contrasenya;
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor - MWR</title>

    <style>
        body {
            background: radial-gradient(circle, #ff3333, #cc0000);
            color: white;
            padding-top: 50px;
        }

        form {
            border: 2px solid black;
            background-color: white;
            margin-top: 50px;
            margin-left: 300px;
            width: 50%;
            display: flex;
            flex-wrap: wrap;
            text-align: center;
            color: black;
        }

        input {
            display: inline-block;
            border: 1px solid black;
            margin-top: 20px;
            margin-left: 5px;
            margin-bottom: 20px;
            width: 200px;
        }

        label {
            display: inline-block;
            margin-top: 20px;
            margin-left: 10px;
            margin-bottom: 20px;
            width: 90px;
        }

        .button {
            margin-left: 220px;
        }

        a {
            text-decoration: none;
            color: black;
            border: 1px solid black;
            background-color: white;
            border-radius: 5px;
            padding: 3px;
        }
    </style>
    <script>
        function mostrarPopup(mensaje) {
            alert(mensaje);
        }
    </script>
</head>

<body>
    <h2>Aquí puedes dar de alta a un nuevo trabajador</h2>
    <p>Una vez registrado el trabajador, le llegará un correo, al correo proporcionado con sus datos de acceso al Intranet de MWR.</p>
    <a href="./utrabajador.php">Volver a página anterior</a>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

        <?php
        // Manejar el registro de usuarios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibir datos del formulario
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $dni = $_POST["dni"];
    $telefono = $_POST["telefono"];
    $correo = $_POST["correo"];
    $usuario = $_POST["usuario"];
    $contrasenya = $_POST["contrasenya"];
    $role = 'Trabajador';

    // Verificar si el nombre de usuario ya existe en la base de datos
    $query_check_user = "SELECT * FROM trabajadores WHERE usuario = '$usuario'";
    $result_check_user = mysqli_query($connexio, $query_check_user);

    if (mysqli_num_rows($result_check_user) > 0) {
        // El nombre de usuario ya está en uso, mostrar mensaje de error
        echo "<script>mostrarPopup('El nombre de usuario ya está en uso');</script>";
    } else {
        // Insertar los datos en la base de datos
        $query_insert = "INSERT INTO trabajadores (nombre, apellido, dni, telefono, correo, usuario, contrasenya, role) 
                         VALUES ('$nombre', '$apellido', '$dni', '$telefono', '$correo', '$usuario', '$contrasenya', 'Trabajador')";

        $result_insert = mysqli_query($connexio, $query_insert);

        if ($result_insert) {
            // Registro exitoso, puedes redirigir a una página de éxito o mostrar un mensaje
            echo "<script>mostrarPopup('Se ha creado el usuario correctamente');</script>";
        } else {
            // Error en el registro, puedes mostrar un mensaje de error o registrar el error en un archivo de registro
            echo "<script>mostrarPopup('Error al crear el usuario');</script>";
        }
    }
}
        ?>

        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" placeholder="Nombre" required><br>

        <label for="apellido">Apellido:</label><br>
        <input type="text" id="apellido" name="apellido" placeholder="Apellido" required><br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" placeholder="DNI" required><br>

        <label for="telefono">Telefono:</label>
        <input type="text" id="telefono" name="telefono" placeholder="Telefono" required><br>

        <label for="correo">Correo:</label>
        <input type="email" id="correo" name="correo" placeholder="Correo"><br>

        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" placeholder="Usuario"><br>

        <input type="submit" value="Añadir Trabajador" class="button">
    </form>
</body>

</html>
