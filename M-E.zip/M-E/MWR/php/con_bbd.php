<?php
    $servidor = 'db';
    $usuari = 'root';
    $clau = 'root';
    $bbdd = "mwr";
    $port = 3306;
    $connexio = mysqli_connect($servidor,$usuari,$clau,$bbdd,$port);
?>
