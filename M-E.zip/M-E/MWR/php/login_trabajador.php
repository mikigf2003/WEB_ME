<?php
session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}

// Manejar el cierre de sesión
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("login_trabajador.php");
    exit();
}

// Manejar el inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $usuario = $_POST["usuario"];
    $contrasenya = $_POST["contrasenya"];
    $contrasenya = md5($contrasenya);

    // Realizar una consulta para verificar las credenciales
    $query = "SELECT * FROM trabajadores WHERE usuario = '$usuario' AND contrasenya = '$contrasenya'";
    $result = mysqli_query($connexio, $query);

    if (mysqli_num_rows($result) > 0) {
        $usuario = mysqli_fetch_assoc($result);
        $_SESSION["usuario"] = $usuario["usuario"];
        $_SESSION["role"] = $usuario["role"];

        // Redirigir según el rol
        if ($usuario["role"] == "Administrador") {
            $_SESSION['authenticated'] = true;
            jsRedirect("administrador.php");
            exit();
        } else if ($usuario["role"] == "Trabajador") {
            $_SESSION['authenticated'] = true;
            jsRedirect("trabajador.php");
            exit();
        } else {
            echo "Credenciales incorrectas";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor - MWR Transportes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container-form {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 500px;
            max-width: 90%;
        }

        .information {
            background-color: #ec5353;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .information h2 {
            margin-bottom: 10px;
            font-size: 1.5rem;
        }

        .information p {
            font-size: 1rem;
        }

        .form-information {
            padding: 20px;
        }

        .form-information h2 {
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: #333;
        }

        .form label {
            display: block;
            margin-bottom: 15px;
        }

        .form input[type="text"],
        .form input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        .form input[type="submit"] {
            background-color: #ef5353;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .form input[type="submit"]:hover {
            background-color: red;
        }

        .center-text {
            text-align: center;
            margin-top: 20px;
        }

        .error-message {
            color: #ff0000;
            margin-top: 10px;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>
    <div class="container-form login hide">
        <div class="information">
            <div class="info-childs">
                <h2>¡¡Bienvenido al gestor de MWR!!</h2>
                <p>Accede con tus credenciales, para poder trabajar y usar el gestor con total libertad</p>
            </div>
        </div>
        <div class="form-information">
            <div class="form-information-childs">
                <h2>Iniciar Sesión</h2>
                <form action="login_trabajador.php" class="form form-register" method="post">
                    <div>
                        <label>
                            <input type="text" id="usuario" name="usuario" placeholder="Usuario">
                        </label>
                    </div>
                    <div>
                        <label>
                            <input type="password" id="contrasenya" name="contrasenya" placeholder="Contraseña">
                        </label>
                    </div>
                    <input type="hidden" name="login">
                    <input type="submit" value="Iniciar Sesión">
                </form>
            </div>
        </div>
    </div>
</body>

</html>
