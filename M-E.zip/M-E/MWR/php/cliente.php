<?php
session_start();
include "con_bbd.php";

function jsRedirect($url) {
    echo "<script>window.location.href = '$url';</script>";
    exit();
}

// Verifica si el usuario está autenticado; si no lo está, redirige a la página de inicio de sesión
if (!$_SESSION['authenticated']) {
    jsRedirect("login_intranet.php");
}

// Destruye la sesión y redirige a la página de inicio de sesión si se envía el formulario oculto
if (isset($_POST['hidden'])) {
    session_destroy();
    jsRedirect("login_intranet.php");
}

function cerrarSesion()
{
    // Destruye todas las variables de sesión
    session_unset();

    // Destruye la sesión
    session_destroy();

    // Redirige al usuario a la página de inicio de sesión
    jsRedirect("../html/home.html");
    exit;
}

// Verifica si se ha enviado el parámetro para salir
if (isset($_GET['salir'])) {
    // Cierra la sesión
    cerrarSesion();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intranet - MWR Transportes</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            justify-content: center;
        }

        h2 {
            text-align: left;

        }

        .h2 {

            border-top: 1px solid black;
            width: 80%;
            padding-top: 100px;
            margin-top: 100px;
            margin-left: 100px;
        }

        h3 {
            background-color: white;
            text-align: center;
        }

        div {
            text-align: center;
            margin-left: 200px;
        }

        a {
            color: white;
            text-decoration: none;
        }

        p {
            text-align: left;
        }

        .datos-cliente {
            margin: 20px auto;
            margin-left: 100px;
            max-width: 1100px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.8);

        }

        .datos-cliente1 {
            margin: 20px auto;
            margin-left: 150px;
            max-width: 1000px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.8);

        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table th,
        table td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        table th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f5f5f5;
        }

        .buttonsalir {
            margin-left: 60px;
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 2px;
            padding-bottom: 2px;
            border-radius: 10px;
            background-color: white;
            color: black;
            vertical-align: bottom;
        }

        form {

            border: 1px solid black;
            background-color: white;
            margin-top: 50px;
            margin-left: 300px;
            width: 59%;
            display: flex;
            flex-wrap: wrap;
            text-align: center;
            color: black;
        }

        input {

            display: inline-block;
            border: 1px solid black;
            margin-top: 20px;
            margin-left: 5px;
            margin-right: 5px;
            margin-bottom: 20px;
            width: 200px;

        }

        label {

            display: inline-block;
            margin-top: 20px;
            margin-left: 10px;
            margin-bottom: 20px;
            width: 150px;

        }

        .button {

            margin-left: 290px;
        }

        .buttonsalir {

            margin-left: 650px;
            margin-bottom: 50px !important;
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 2px;
            padding-bottom: 2px;
            border: 1px solid black;
            border-radius: 10px;
            background-color: black;
            color: white;
        }

        .buttonsalir:hover{

            background-color: white;
            color: black;
        }
        
        /* Estilos para pantallas de ordenadores */
@media only screen and (min-width: 768px) {
    .container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
}

/* Estilos para pantallas de televisión */
@media only screen and (min-width: 1200px) {
    .datos-cliente {
            margin: 20px auto;
            margin-left: 400px;
            max-width: 1100px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.8);

        }

        .datos-cliente1 {
            margin: 20px auto;
            margin-left: 400px;
            max-width: 1000px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.8);

        }
        
         form {

            border: 1px solid black;
            background-color: white;
            margin-top: 50px;
            margin-left: 400px;
            width: 50%;
            display: flex;
            flex-wrap: wrap;
            text-align: center;
            color: black;
        }
}
    </style>
    <script>
        function mostrarPopup(mensaje) {
            alert(mensaje);
        }
    </script>
</head>

<body>
    <div class="background-container">
        <h1>Bienvenido a la Intranet de MWR</h1>
        <h2>¡Explora nuestros servicios y recursos!</h2>
        <p>¡Hola <?php echo $_SESSION["usuario"]; ?>!, aquí puedes hacer tus gestiones</p>
    </div>
    <?php
    // Procesar la actualización si se envió un formulario de edición
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_cliente'])) {
        $id_cliente_editar = $_POST['id_cliente'];
        $nombre_editar = $_POST['nombre'];
        $dni_editar = $_POST['dni'];
        $telefono_editar = $_POST['telefono'];
        $correo_editar = $_POST['correo'];
        $empresa_editar = $_POST['empresa'];

        $sql_actualizar = "UPDATE clientes SET
    nombre = '$nombre_editar', 
    dni = '$dni_editar',
    telefono = '$telefono_editar',
    correo = '$correo_editar',
    empresa = '$empresa_editar'
    WHERE id_cliente = $id_cliente_editar";

        $result = mysqli_query($connexio, $sql_actualizar);

        if ($result) {
            echo "<script>alert('Datos editados correctamente');</script>";
        } else {
            echo "<script>alert('Error al editar datos');</script>";
        }
    }
    // Obtener el nombre de usuario de la sesión
    $usuario = $_SESSION["usuario"];

    // Consulta SQL para obtener los datos del usuario
    $sql_id_cliente = "SELECT * FROM clientes WHERE usuario = '$usuario'";
    $resultado_id_cliente = mysqli_query($connexio, $sql_id_cliente);

    // Obtener los datos del cliente
    $info = mysqli_fetch_assoc($resultado_id_cliente);
    ?>
    <div class="datos-cliente">
        <h2>Actualiza tus datos en el caso necessario</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>DNI</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Empresa</th>
                <th>Editar</th>
            </tr>

            <?php
            // Verificar si se obtuvieron datos del cliente
            if ($info) {
                echo "<tr>";
                echo "<td>" . $info['id_cliente'] . "</td>";
                echo "<form method='post' action='" . $_SERVER['PHP_SELF'] . "'>";
                echo "<input type='hidden' name='id_cliente' value='" . $info['id_cliente'] . "'>";
                echo "<td><input type='text' name='nombre' value='" . $info['nombre'] . "'></td>";
                echo "<td><input type='text' name='dni' style='width:100px;' value='" . $info['dni'] . "'></td>";
                echo "<td><input type='text' name='telefono' style='width:100px;' value='" . $info['telefono'] . "'></td>";
                echo "<td><input type='mail' name='correo' value='" . $info['correo'] . "'></td>";
                echo "<td><input type='text' name='empresa' style='width:120px;' value='" . $info['empresa'] . "'></td>";
                echo "<td><button type='submit' style='width:100px;'name='editar_cliente'>Editar</button></td>";
                echo "</form>";
                echo "</tr>";
            } else {
                echo "<tr><td colspan='7'>No se encontraron datos del cliente.</td></tr>";
            }
            ?>
        </table>
    </div>
    <?php
    // Obtener el id_cliente del usuario
    $id_cliente = $info['id_cliente'];

    // Consulta SQL para obtener los pedidos del usuario
    $sql_transportes = "SELECT * FROM transportes WHERE id_cliente = $id_cliente";
    $resultado_transportes = mysqli_query($connexio, $sql_transportes);
    ?>

    <div class="datos-cliente1">
        <h2>Detalles de tus pedidos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID de Pedido</th>
                    <th>Tipo de Transporte</th>
                    <th>Dirección de Transporte</th>
                    <th>Peso</th>
                    <th>Estado</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($transportes = mysqli_fetch_assoc($resultado_transportes)) {
                    echo "<tr>";
                    echo "<td>" . $transportes['id_transporte'] . "</td>";
                    echo "<td>" . $transportes['tipo_transporte'] . "</td>";
                    echo "<td>" . $transportes['direccion_transporte'] . "</td>";
                    echo "<td>" . $transportes['peso'] . "</td>";
                    echo "<td>" . $transportes['estado'] . "</td>";
                    echo "<td>" . $transportes['descripcion'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
    // Manejar el registro de usuarios
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Recibir datos del formulario
        $id_cliente = $info["id_cliente"];
        $tipo_transporte = $_POST["tipo_transporte"];
        $direccion_transporte = $_POST["direccion_transporte"];
        $peso = $_POST["peso"];
        $estado = 'Pendiente';
        $descripcion = $_POST["descripcion"];


        // Insertar los datos en la base de datos
        $query = " INSERT INTO transportes ( id_cliente, tipo_transporte, direccion_transporte, peso, estado, descripcion, id_transportista) 
VALUES ('$id_cliente', '$tipo_transporte', '$direccion_transporte', '$peso', '$estado', '$descripcion', NULL);";

        $result = mysqli_query($connexio, $query);

        if ($result) {
            // Registro exitoso, puedes redirigir a una página de éxito o mostrar un mensaje
            echo "<script>mostrarPopup('Registro exitoso');</script>";
        } else {
            // Error en el registro, puedes mostrar un mensaje de error o registrar el error en un archivo de registro
            echo "<script>mostrarPopup('Error al registrarte');</script>" . mysqli_error($connexio);
        }
    }
    ?>

    <h2 class="h2">Encraga tu próximo transporte en cuestión de minutos</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" style="margin-bottom: 50px;">
        <label for="tipo_transporte">Tipo de Transporte:</label><br>
        <input type="text" id="tipo_transporte" name="tipo_transporte" placeholder="Tipo de Transporte" required><br>

        <label for="direccion_transporte">Dirección:</label><br>
        <input type="text" id="direccion_transporte" name="direccion_transporte" placeholder="Dirección de Transporte" required><br>

        <label for="peso">Peso:</label><br>
        <input type="text" id="peso" name="peso" style="width: 500px;" placeholder="Peso" required><br>

        <label for="descripcion">Descripción:</label><br>
        <input type="text" id="descripcion" name="descripcion" style="width: 500px; height: 100px;" placeholder="Descripción" required><br>

        <input type="submit" value="Encargar pedido" class="button">
    </form>

    <a href="<?php echo $_SERVER['PHP_SELF']; ?>?salir=1" class="buttonsalir">Cerrar Sessión</a>
</body>

</html>
