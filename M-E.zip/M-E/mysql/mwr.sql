-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 20-05-2024 a las 09:32:37
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mwr`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `dni` varchar(9) DEFAULT NULL,
  `telefono` int(9) NOT NULL,
  `correo` varchar(40) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasenya` varchar(100) NOT NULL,
  `empresa` varchar(25) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `dni`, `telefono`, `correo`, `usuario`, `contrasenya`, `empresa`, `role`) VALUES
(2, 'Daniel Mascarilla', '47389231J', 675109876, 'damade@jviladoms.cat', 'Daniel', '81dc9bdb52d04dc20036dbd8313ed055', 'Amazon', 'Cliente'),
(5, 'Daniel Peula', '48270987', 654321765, 'dapega@gmail.com', 'dapega', '81dc9bdb52d04dc20036dbd8313ed055', 'Infolabs', 'Cliente'),
(12, 'Sergi', '45678932P', 62345678, 'sergi@jviladoms.cat', 'sergi', '81dc9bdb52d04dc20036dbd8313ed055', 'Mediamarkt4', 'Cliente'),
(7, 'Ana', '47563232', 654325143, 'anaisabel@gmail.com', 'anaisabel', '81dc9bdb52d04dc20036dbd8313ed055', 'Imatgeicolor', 'Cliente'),
(8, 'Alberto', '45367281', 654325143, 'alberto@gmail.com', 'almube', '81dc9bdb52d04dc20036dbd8313ed055', 'Amazon', 'Cliente'),
(38, 'Carla', '43828732G', 675432134, 'carla@gmail.com', 'carla', '81dc9bdb52d04dc20036dbd8313ed055', '', 'Cliente'),
(13, 'Marcos', '', 65456789, 'marcos@gmail.com', 'marcos', '81dc9bdb52d04dc20036dbd8313ed055', 'Amazon', 'Cliente'),
(28, 'Miquel', '', 654325143, 'migofe@jviladoms.cat', 'migofe', '81dc9bdb52d04dc20036dbd8313ed055', 'Imatgeicolor', 'Cliente'),
(27, 'Miquel', '', 654329823, 'miquel@gmail.com', 'miquel', '81dc9bdb52d04dc20036dbd8313ed055', 'Zabbix', 'Cliente'),
(29, 'Enzo', '43828732G', 67399402, 'enzo@jviladoms.cat', 'enzo', '81dc9bdb52d04dc20036dbd8313ed055', 'Amazon', 'Cliente'),
(25, 'Raul', NULL, 678987654, 'raulda@jviladoms.cat', 'raulda', '81dc9bdb52d04dc20036dbd8313ed055', NULL, 'Cliente'),
(37, 'Enzo', '43828732G', 67399402, 'enzo@jviladoms.cat', 'enza', 'f2237e26d0497a3ce367f34e2fa083fa', 'Amazon', 'Cliente'),
(41, 'Manolo', NULL, 654321987, 'manolo@gmail.com', 'manolo', '81dc9bdb52d04dc20036dbd8313ed055', NULL, 'Cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trabajadores`
--

DROP TABLE IF EXISTS `trabajadores`;
CREATE TABLE IF NOT EXISTS `trabajadores` (
  `id_trabajador` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `dni` varchar(9) NOT NULL,
  `telefono` int(9) NOT NULL,
  `correo` varchar(25) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasenya` varchar(40) NOT NULL,
  `role` text NOT NULL,
  PRIMARY KEY (`id_trabajador`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `trabajadores`
--

INSERT INTO `trabajadores` (`id_trabajador`, `nombre`, `apellido`, `dni`, `telefono`, `correo`, `usuario`, `contrasenya`, `role`) VALUES
(1, 'Miquel', 'Gonzalez', '49270183Z', 601251062, 'migofe@jviladoms.cat', 'migofe', '81dc9bdb52d04dc20036dbd8313ed055', 'Administrador'),
(3, 'Eloi', 'Carbonell', '47569876', 675102584, 'elcaro@jviladoms.cat', 'elcaro', '81dc9bdb52d04dc20036dbd8313ed055', 'Trabajador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transportes`
--

DROP TABLE IF EXISTS `transportes`;
CREATE TABLE IF NOT EXISTS `transportes` (
  `id_transporte` int(6) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(10) NOT NULL,
  `tipo_transporte` varchar(30) NOT NULL,
  `direccion_transporte` varchar(100) NOT NULL,
  `peso` int(10) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `descripcion` varchar(1000) NOT NULL,
  `id_transportista` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_transporte`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_transportista` (`id_transportista`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `transportes`
--

INSERT INTO `transportes` (`id_transporte`, `id_cliente`, `tipo_transporte`, `direccion_transporte`, `peso`, `estado`, `descripcion`, `id_transportista`) VALUES
(1, 7, 'Aereo', 'Calle Plini el Vell, Sabadell', 40, 'Pendiente', 'Lorem ipsu Lorem ipsu Lorem ipsu Lorem ipsu Lorem ipsu', 4),
(2, 11, 'Aereo', 'Calle Doctor Moragas, Sabadell', 240, 'Pendiente', 'Lorem ipsumm lorem ipsummm', 4),
(3, 12, 'Maritimo', 'Calle Aimerigas,4 Barcelona', 240, 'En curso', 'lsllslslsls', 4),
(4, 12, 'Aereo', 'Zimbaue', 3000, 'Pendiente', 'Medicinas para el tercer mundo', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transportista`
--

DROP TABLE IF EXISTS `transportista`;
CREATE TABLE IF NOT EXISTS `transportista` (
  `id_transportista` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `edad` int(2) NOT NULL,
  `dni` varchar(9) NOT NULL,
  `experiencia` varchar(30) NOT NULL,
  `telefono` int(9) NOT NULL,
  `servicio` varchar(15) NOT NULL,
  PRIMARY KEY (`id_transportista`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `transportista`
--

INSERT INTO `transportista` (`id_transportista`, `nombre`, `edad`, `dni`, `experiencia`, `telefono`, `servicio`) VALUES
(4, 'Manolo', 50, '345678901', '27', 612345672, 'maritimo');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
